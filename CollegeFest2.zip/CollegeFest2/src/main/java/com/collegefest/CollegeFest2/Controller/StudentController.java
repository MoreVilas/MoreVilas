package com.collegefest.CollegeFest2.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.collegefest.CollegeFest2.Entity.Student;
import com.collegefest.CollegeFest2.Service.StudentService;

@Controller
@RequestMapping("/api/students")
public class StudentController {

	@Autowired
	private StudentService studentService;

	@GetMapping("/list")
	public String listStudents(Model theModel) {
		List<Student> students = this.studentService.findAll();
		theModel.addAttribute("Student", students);
		return "studentList";
	}

	@GetMapping("/findById")
	public String findById(@RequestParam("studentId") int id) {
		studentService.findById(id);
		return "student";
	}

	@RequestMapping("/deleteById")
	public String deleteById(@RequestParam("studentId") int id) {
		studentService.deleteById(id);
		return "redirect:studentList";
	}

	@RequestMapping("/save")
	public String saveStudent(Student student) {
		Student theStudent;
		if (student.getId() != 0) {
			theStudent = studentService.findById(student.getId());
			theStudent.setFname(student.getFname());
			theStudent.setLname(student.getLname());
			theStudent.setCourse(student.getCourse());
			theStudent.setCountry(student.getCountry());
		} else
			theStudent = new Student(student.getFname(), student.getLname(), student.getCourse(), student.getCountry());
		studentService.save(theStudent);
		return "redirect:studentList";
	}
	@RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {
		Student theStudent = new Student();
		
		theModel.addAttribute("Student", theStudent);
		return "studentForm";
	}
	@RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("studentId") int id, Model theModel) {
		
		Student theStudent = studentService.findById(id);
		theModel.addAttribute("Student", theStudent);
		return "studentForm";
	}
	

}