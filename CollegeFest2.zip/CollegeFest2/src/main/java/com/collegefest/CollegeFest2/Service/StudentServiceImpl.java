package com.collegefest.CollegeFest2.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.collegefest.CollegeFest2.Entity.Student;
import com.collegefest.CollegeFest2.Repo.StudentRepo;

@Service
public class StudentServiceImpl implements StudentService{
	
	@Autowired
	private StudentRepo repo;

	@Override
	public List<Student> findAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Student findById(int theId) {
		// TODO Auto-generated method stub
		return repo.findById(theId).get();
	}

	@Override
	public void save(Student theStudent) {
		// TODO Auto-generated method stub
		repo.save(theStudent);
	}

	@Override
	public void deleteById(int Id) {
		// TODO Auto-generated method stub
		repo.deleteById(Id);
	}

}
