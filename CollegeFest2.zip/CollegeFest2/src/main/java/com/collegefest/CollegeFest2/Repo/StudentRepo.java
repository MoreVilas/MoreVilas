package com.collegefest.CollegeFest2.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.collegefest.CollegeFest2.Entity.Student;

public interface StudentRepo extends JpaRepository<Student, Integer>{

}
