package com.collegefest.CollegeFest2.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.collegefest.CollegeFest2.Entity.Student;

@Service
public interface StudentService {
	
	public List<Student> findAll();
	
	public Student findById(int theId);
	
	public void save(Student theStudent);
	
	public void deleteById(int Id);

}
