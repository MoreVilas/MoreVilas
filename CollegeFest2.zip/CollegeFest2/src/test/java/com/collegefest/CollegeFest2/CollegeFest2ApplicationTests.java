package com.collegefest.CollegeFest2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeFest2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
